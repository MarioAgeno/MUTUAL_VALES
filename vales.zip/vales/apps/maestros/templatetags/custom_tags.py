# vales\apps\maestros\templatetags\custom_tags.py
from django import template
from decimal import Decimal, InvalidOperation
import locale
from babel.numbers import format_decimal

register = template.Library()


@register.filter(name='get_attribute')
def get_attribute(value, arg):
	"""
	Obtiene el valor de un atributo de un objeto.
	"""
	try:
		return getattr(value, arg)
	except AttributeError:
		return None


@register.filter(name='get_item')
def get_item(dictionary, key):
	"""
	Obtiene un valor de un diccionario dada una clave.
	
	Args:
		dictionary (dict): El diccionario del cual se quiere obtener el valor.
		key (str): La clave a buscar en el diccionario.
	
	Returns:
		any: El valor asociado con la clave en el diccionario, o None si la clave no se encuentra.
	"""
	return dictionary.get(key, None)


@register.filter(name='get_columna')
def get_columna(field, field_name):
	"""
		Obtiene el valor de la columna definida en los atributos extra de un campo de formulario.
		
		Este filtro busca en el diccionario 'extra_attrs' del widget del campo el valor de la clave 'columna'.
		Si la clave 'columna' no se encuentra en 'extra_attrs', devuelve un valor por defecto de 12.
		
		Args:
			field: El campo del formulario del cual se quiere obtener el valor de la columna.
			field_name: El nombre del campo (no se utiliza en la función, pero se incluye para mantener la compatibilidad con la etiqueta de plantilla).
		
		Returns:
			int: El valor de la columna definido en los atributos extra del campo, o 12 si no se encuentra.
	"""
	extra_attrs = field.widget.attrs.get('extra_attrs', {})
	return extra_attrs.get('columna', 12)  # Si no se encuentra, se devuelve 12 por defecto


@register.filter
def get_type(value):
	""" Devuelve el tipo de valor en formato string."""
	return type(value).__name__


@register.filter
def formato_es_ar(value):
    if value is None or value == "":
        return ""
    try:
        # Asegura Decimal para evitar floats raros
        value = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return value

    # es_AR: miles con punto, decimales con coma
    return format_decimal(value, locale="es_AR")


@register.filter
def formato_es_ar_entero(value):
    """
    Formatea un número entero con el formato de Argentina:
    - Separador de miles: punto (.)
    - Sin decimales
    - Compatible con int, float y Decimal.
    """
    try:
        # Configura el locale para números en es_AR
        locale.setlocale(locale.LC_NUMERIC, 'es_AR.UTF-8')
        
        # Convierte a float si es Decimal y luego a int
        if isinstance(value, Decimal):
            value = int(float(value))
        elif isinstance(value, float):
            value = int(value)
            
        # Formatea con separadores de miles y sin decimales
        return locale.format_string('%d', value, grouping=True)
    except (ValueError, TypeError):
        # Devuelve el valor sin formatear si no es un número válido
        return value



@register.filter
def get_estatus(estatus):
	return "Activo" if estatus else "Inactivo"


@register.filter
def get_si_no(estatus):
	return "Si" if estatus else "No"


@register.filter
def get_display_value(obj, field_name):
	"""
	Obtiene el valor de display para un campo con choices, si existe.
	Si no, devuelve el valor original.
	"""
	try:
		display_method = f'get_{field_name}_display'
		if hasattr(obj, display_method):
			return getattr(obj, display_method)()
		else:
			return getattr(obj, field_name)
	except AttributeError:
		return getattr(obj, field_name, None)