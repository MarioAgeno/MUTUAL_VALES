# neumatic\apps\datatools\urls.py
from django.urls import path



urlpatterns = [
]